use super::cartridge::Cartridge;
use super::mapper::{translate_vram, Mapper, MirrorMode};
use serde::{Deserialize, Serialize};
use serde_big_array::big_array;

big_array! { BigArray; 2048, 8192 }

#[derive(Serialize, Deserialize)]
pub struct MapperMmc2 {
    #[serde(skip)]
    cart: Cartridge,
    #[serde(with = "BigArray")]
    ram: [u8; 8192],
    #[serde(with = "BigArray")]
    vram: [u8; 2048],
    mirror_mode: MirrorMode,

    chr_bank_0_0: u8,
    chr_bank_0_1: u8,
    chr_bank_1_0: u8,
    chr_bank_1_1: u8,
    prg_bank_8000: usize,
    prg_bank_c000: usize,

    latch_0: bool,
    latch_1: bool,
}

impl MapperMmc2 {
    pub const ID: u8 = 9;

    pub fn new(cart: Cartridge) -> MapperMmc2 {
        let mirror_mode = match cart.mirror_mode {
            0 => MirrorMode::MirrorVertical,
            1 => MirrorMode::MirrorHorizontal,
            _ => panic!("Unsupported cart mirror mode: {}", cart.mirror_mode),
        };
        let prg_last = (cart.prg_rom.len() / 0x4000).wrapping_sub(1);
        MapperMmc2 {
            cart,
            ram: [0; 8192],
            vram: [0; 2048],
            mirror_mode,
            chr_bank_0_0: 0,
            chr_bank_0_1: 0,
            chr_bank_1_0: 0,
            chr_bank_1_1: 0,
            prg_bank_8000: 0,
            prg_bank_c000: prg_last,
            latch_0: false,
            latch_1: false,
        }
    }
}

impl Mapper for MapperMmc2 {
    fn peek(&mut self, addr: u16) -> u8 {
        match addr {
            0x0000..=0x0FFF => {
                let bank = if !self.latch_0 {
                    self.chr_bank_0_0 as usize
                } else {
                    self.chr_bank_0_1 as usize
                };
                let data = self.cart.chr_rom[bank * 0x1000 + (addr & 0xFFF) as usize];
                if addr & 0x0FF8 == 0x0FD8 || addr & 0x0FF8 == 0x0FE8 {
                    self.latch_0 = !self.latch_0;
                }
                data
            }
            0x1000..=0x1FFF => {
                let bank = if !self.latch_1 {
                    self.chr_bank_1_0 as usize
                } else {
                    self.chr_bank_1_1 as usize
                };
                let data = self.cart.chr_rom[bank * 0x1000 + (addr & 0xFFF) as usize];
                if addr & 0x0FF8 == 0x0FD8 || addr & 0x0FF8 == 0x0FE8 {
                    self.latch_1 = !self.latch_1;
                }
                data
            }
            0x2000..=0x3EFF => self.vram[translate_vram(self.mirror_mode, addr)],

            0x6000..=0x7FFF => self.ram[(addr & 0x1FFF) as usize],
            0x8000..=0xBFFF => {
                let offset = self.prg_bank_8000 * 0x4000;
                self.cart.prg_rom[offset + (addr & 0x3FFF) as usize]
            }
            0xC000..=0xFFFF => {
                let offset = self.prg_bank_c000 * 0x4000;
                self.cart.prg_rom[offset + (addr & 0x3FFF) as usize]
            }
            _ => 0,
        }
    }

    fn poke(&mut self, addr: u16, val: u8) {
        match addr {
            0x0000..=0x0FFF => {
                let bank = if !self.latch_0 {
                    self.chr_bank_0_0 as usize
                } else {
                    self.chr_bank_0_1 as usize
                };
                self.cart.chr_rom[bank * 0x1000 + (addr & 0xFFF) as usize] = val;
            }
            0x1000..=0x1FFF => {
                let bank = if !self.latch_1 {
                    self.chr_bank_1_0 as usize
                } else {
                    self.chr_bank_1_1 as usize
                };
                self.cart.chr_rom[bank * 0x1000 + (addr & 0xFFF) as usize] = val;
            }
            0x2000..=0x3EFF => self.vram[translate_vram(self.mirror_mode, addr)] = val,

            0x6000..=0x7FFF => self.ram[(addr & 0x1FFF) as usize] = val,

            0xA000..=0xAFFF => self.chr_bank_0_0 = val,
            0xB000..=0xBFFF => self.chr_bank_1_0 = val,
            0xC000..=0xCFFF => self.chr_bank_0_1 = val,
            0xD000..=0xDFFF => self.chr_bank_1_1 = val,
            0xE000..=0xEFFF => {
                self.prg_bank_8000 = (val as usize) % (self.cart.prg_rom.len() / 0x4000);
            }
            0xF000..=0xFFFF => {
                self.prg_bank_c000 = (val as usize) % (self.cart.prg_rom.len() / 0x4000);
            }
            _ => {}
        };
    }

    fn get_id(&self) -> u8 {
        Self::ID
    }

    fn update_cartridge(&mut self, cartridge: Cartridge) {
        self.cart = cartridge;
    }
}
